# Montefiore PDF/UA working environment split package

This is one part of the split startup bundle created from montefiore_pdfua_working_environment_2026-05-07.

Binaries are intentionally not included:
- qpdf 12.3.2
- veraPDF Greenfield 1.30.1

Recommended restore order:
1. Unzip part01_core_rules_runbook_skill.zip
2. Unzip part02_scripts.zip into the same working folder
3. Unzip part03_examples_source_qa.zip into the same working folder
4. Unzip part04_examples_known_good_a.zip and part05_examples_known_good_b.zip as needed for examples/regression references

Start with README_START_HERE.md and docs/RUNBOOK.md from part01.
