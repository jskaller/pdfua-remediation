# MMC FA Policy JF14.1. Haitian Creole 04.23.2026.pdf

Status: PRODUCTION_FINAL_METADATA_ONLY

- Metadata-only update: yes
- Prominent language: Haitian Creole (ht)
- veraPDF PDF/UA-1: PASS
- qpdf: PASS
- Content/layout changes: none intentional

## Metadata

- Author: Montefiore Einstein
- Creator: Montefiore Einstein
- Producer: Montefiore Einstein
- Title: Politik Èd Finansye JF14.1 - Kreyòl Ayisyen
- Subject: Politik Èd Finansye JF14.1 Sant Medikal Montefiore dekri kalifikasyon, sèvis ki kouvri, pwosedi aplikasyon, pratik faktirasyon ak direktiv pou asistans finansye.
- Description: Politik Èd Finansye JF14.1 Sant Medikal Montefiore dekri kalifikasyon, sèvis ki kouvri, pwosedi aplikasyon, pratik faktirasyon ak direktiv pou asistans finansye.
- Keywords: Montefiore Einstein, Sant Medikal Montefiore, politik èd finansye, asistans finansye, JF14.1, swen charite, faktirasyon, sèvis finansye pasyan, FAP, Kreyòl Ayisyen
- Language: ht
