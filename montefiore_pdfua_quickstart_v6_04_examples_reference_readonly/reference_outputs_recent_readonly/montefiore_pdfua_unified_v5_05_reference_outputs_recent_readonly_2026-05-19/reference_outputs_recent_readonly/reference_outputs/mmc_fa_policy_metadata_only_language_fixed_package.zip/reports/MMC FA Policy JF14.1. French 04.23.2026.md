# MMC FA Policy JF14.1. French 04.23.2026.pdf

Status: PRODUCTION_FINAL_METADATA_ONLY

- Metadata-only update: yes
- Prominent language: French (fr)
- veraPDF PDF/UA-1: PASS
- qpdf: PASS
- Content/layout changes: none intentional

## Metadata

- Author: Montefiore Einstein
- Creator: Montefiore Einstein
- Producer: Montefiore Einstein
- Title: Politique d'aide financière JF14.1 - Français
- Subject: La Politique d'aide financière JF14.1 du Centre médical Montefiore décrit l'admissibilité, les services couverts, les procédures de demande, les pratiques de facturation et les lignes directrices relatives à l'aide financière.
- Description: La Politique d'aide financière JF14.1 du Centre médical Montefiore décrit l'admissibilité, les services couverts, les procédures de demande, les pratiques de facturation et les lignes directrices relatives à l'aide financière.
- Keywords: Montefiore Einstein, Centre médical Montefiore, politique d'aide financière, aide financière, JF14.1, soins de bienfaisance, facturation, services financiers aux patients, FAP, Français
- Language: fr
