# Metadata Ruleset Addendum

## Metadata-Only Repair Scope
For metadata-only work on already-remediated PDFs, do not intentionally alter page content, layout, tags, forms, links, annotations, or visual rendering. Update only document information dictionary metadata, XMP metadata, and root `/Lang` when needed.

## Required Metadata Fields
Every delivered PDF must include Author, Creator, Producer, Title, Subject, Description, Keywords, and Language. Author, Creator, and Producer must be `Montefiore Einstein`.

## Prominent-Language Metadata Gate
Metadata must be written in the prominent language of the PDF. The `/Lang` value, XMP `dc:language`, Title, Subject, Description, and Keywords must match the document's primary visible language unless a documented reason exists. Organization and brand names such as `Montefiore Einstein` and `Montefiore Medical Center` may remain in brand form.

## Content-Specific Metadata Quality Gate
Title, Subject, Description, and Keywords must be derived from the visible title, first page, headings, and substantive body content. Generic boilerplate fails unless the Controlled Metadata Fallback Rule is explicitly invoked and documented.

## Controlled Metadata Fallback Rule
If a document is sparse, image-only, ambiguous, or not well understood after reasonable inspection, the controlled fallback may be used: Description `Montefiore Einstein document - {Document Title}` and Keywords `Montefiore Einstein, {Document Title}` or a prominent-language equivalent. Fallback use must be documented.
