# MMC Financial Aid Policy Metadata-Only Rework

Files reprocessed: 7

- Scope: metadata only
- veraPDF PDF/UA-1: 7 / 7 PASS
- qpdf: 7 / 7 PASS
- Content/layout changes: none intentional
- Full-page rasterization: none
- OCR substitution: none

## Metadata rule applied

Author, Creator, and Producer were set to `Montefiore Einstein`. Title, Subject, Description, Keywords, root `/Lang`, document info `/Language`, and XMP language were completed in each document's prominent language.

## Files
- `MMC FA Policy JF14.1. Albanian 04.23.2026.pdf` - Albanian (sq) - metadata PASS, veraPDF PASS, qpdf PASS
- `MMC FA Policy JF14.1. English 04.23.2026.pdf` - English (en-US) - metadata PASS, veraPDF PASS, qpdf PASS
- `MMC FA Policy JF14.1. French 04.23.2026.pdf` - French (fr) - metadata PASS, veraPDF PASS, qpdf PASS
- `MMC FA Policy JF14.1. Greek 04.23.2026.pdf` - Greek (el) - metadata PASS, veraPDF PASS, qpdf PASS
- `MMC FA Policy JF14.1. Haitian Creole 04.23.2026.pdf` - Haitian Creole (ht) - metadata PASS, veraPDF PASS, qpdf PASS
- `MMC FA Policy JF14.1. Italian 04.23.2026.pdf` - Italian (it) - metadata PASS, veraPDF PASS, qpdf PASS
- `MMC FA Policy JF14.1. Spanish 04.23.2026.pdf` - Spanish (es) - metadata PASS, veraPDF PASS, qpdf PASS