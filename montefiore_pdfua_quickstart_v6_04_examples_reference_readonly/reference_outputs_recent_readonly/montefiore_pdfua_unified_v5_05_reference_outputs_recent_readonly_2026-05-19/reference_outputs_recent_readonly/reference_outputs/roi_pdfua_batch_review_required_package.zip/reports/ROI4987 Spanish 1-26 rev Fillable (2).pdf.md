# ROI4987 Spanish 1-26 rev Fillable (2).pdf

Status: **VERAPDF_PASS_REVIEW_REQUIRED**

- veraPDF PDF/UA-1: PASS
- qpdf --check: PASS
- Page count: 2 -> 2
- Text words: 1514 -> 0
- Widgets: 102 -> 102
- Links: 0 -> 0
- Images: 3 -> 2
- Full-page rasterization: Yes, review-required route
- OCR substitution: No
- Metadata prominent-language gate: PASS

Review reason: Full-page raster visual preservation route used to achieve PDF/UA pass; native text extraction is reduced and manual review is required under the Native Text Preservation Gate.
