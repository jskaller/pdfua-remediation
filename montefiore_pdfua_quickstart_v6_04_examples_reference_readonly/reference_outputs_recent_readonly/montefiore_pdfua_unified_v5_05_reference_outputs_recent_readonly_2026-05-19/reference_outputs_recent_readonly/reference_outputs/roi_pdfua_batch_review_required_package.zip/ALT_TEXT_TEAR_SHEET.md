# Alt Text Tear Sheet

- English instructions: full-page figure alt describes the Montefiore ROI4987 completion instructions.
- Spanish instructions: full-page figure alt describes the Spanish Montefiore ROI4987 completion instructions.
- English fillable ROI4987: full-page figure alt describes the fillable HIPAA authorization form; live form widgets retain tooltips/alternate text.
- Spanish fillable ROI4987: full-page figure alt describes the Spanish fillable HIPAA authorization form; live form widgets retain tooltips/alternate text.
