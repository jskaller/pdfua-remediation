# Current PDF/UA remediation ruleset addendum

This package applies the current Montefiore Einstein PDF/UA workflow rules, including native preservation first, no production-final raster fallback, live AcroForm widget preservation, visual/style preservation, file-size gates, content-specific metadata, and handoff gates.

## Prominent-Language Metadata Gate
Metadata must be written in the prominent language of the PDF. The `/Lang` value, XMP `dc:language`, Title, Subject, Description, and Keywords must match the document's primary visible language unless there is a documented reason not to. For translated documents, do not use English-only descriptions or keywords for non-English PDFs. Organization names such as "Montefiore Einstein" may remain in brand form, but the surrounding description and document-purpose keywords should be in the document language where feasible. If the document language cannot be determined confidently, document the uncertainty and use the controlled fallback.

## Controlled Metadata Fallback Rule
If, after reasonable inspection, the document purpose cannot be confidently determined because the document is image-only, extremely sparse, ambiguous, truncated, technical, or otherwise not well understood, a controlled fallback is allowed. The fallback must be documented and must not be used when purpose is clear.

## Native Text Preservation Gate
For text-heavy, form-like, directory-like, policy-like, application-like, or instruction-like sources, native text must be preserved by default. If a veraPDF-pass route uses full-page raster backgrounds or materially reduces parsed text, it must be routed review-required, never production-final.

## Live AcroForm Widget Preservation Gate
If the source PDF has live AcroForm widgets, the output must preserve live widgets. If source widget count is greater than 0 and output widget count is 0, handoff fails unless flattening was explicitly requested or the file is diagnostic/unfixable.

## Handoff Gate
No file may be production-final unless veraPDF PASS, qpdf PASS, metadata pass, native text/widgets/links/annotations preservation pass, visual comparison pass, and file-size gate pass. Review-required outputs must be clearly separated and labeled.
