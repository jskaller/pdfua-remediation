# PDF/UA Remediation Report - Montefiore ROI form instructions-English (2).pdf

## Status

`VERAPDF_PASS_REVIEW_REQUIRED`

The PDF passes veraPDF PDF/UA-1 and qpdf validation. It is kept review-required because the source is visually text-based but image-only: no native text was parsed from the source, and the output preserves the source page images rather than substituting OCR/live text.

## Validation

- veraPDF PDF/UA-1: PASS
- qpdf 12.3.2 --check: PASS
- Page count: 2 -> 2
- Render comparison: PASS, 0 changed pages

## Preservation

- Full-page rasterization added: No
- OCR substitution: No
- Source parsed words: 0
- Output parsed words: 0
- Source images: 2
- Output images: 2
- Source links: 0
- Output links: 0
- Source widgets: 0
- Output widgets: 0

## Metadata

- Author: Montefiore Einstein
- Creator: Montefiore Einstein
- Producer: Montefiore Einstein
- Language: en-US
- Title: Instructions for Completing Montefiore Authorization for Release of Health Information
- Subject: Instructions for Montefiore authorization to release health information
- Description: Instructions for completing Montefiore's Authorization for Release of Health Information form ROI4987, including patient information, records requested, special protected information, delivery method, authorization expiration, and review and approval.
- Keywords: Montefiore Einstein, Montefiore, authorization for release of health information, ROI4987, HIPAA, health information management, medical records, patient records, disclosure instructions

## Notes

The document is a two-page English instruction sheet for completing Montefiore's Authorization for Release of Health Information form ROI4987. The visible content includes section-by-section guidance for patient information, records requested, special protected information, delivery method and format, authorization expiration, and review/approval.
