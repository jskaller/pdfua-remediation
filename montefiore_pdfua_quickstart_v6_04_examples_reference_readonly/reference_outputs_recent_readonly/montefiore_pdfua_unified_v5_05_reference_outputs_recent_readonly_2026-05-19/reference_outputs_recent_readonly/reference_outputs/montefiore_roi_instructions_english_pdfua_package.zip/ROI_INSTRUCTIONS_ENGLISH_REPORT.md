# ROI Instruction PDF/UA Handoff Report

Files processed: 1

- veraPDF PDF/UA-1: 1 / 1 PASS
- qpdf 12.3.2 --check: 1 / 1 PASS
- Metadata gate: 1 / 1 PASS
- Status: VERAPDF_PASS_REVIEW_REQUIRED

Output: `output_files/VERAPDF_PASS_REVIEW_REQUIRED/Montefiore ROI form instructions-English (2).pdf`

Reason for review-required routing: the source is an image-only text instruction document with zero parsed words. No new full-page rasterization or OCR substitution was added, and the visual rendering is unchanged.
