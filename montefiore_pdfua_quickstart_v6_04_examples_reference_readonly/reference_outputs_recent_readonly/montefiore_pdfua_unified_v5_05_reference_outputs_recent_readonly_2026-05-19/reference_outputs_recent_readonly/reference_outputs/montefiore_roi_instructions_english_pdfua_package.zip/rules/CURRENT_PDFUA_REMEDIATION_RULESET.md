# Current PDF/UA Remediation Ruleset Addendum

## Metadata Completion Gate
Every output PDF must include Author, Creator, and Producer set to `Montefiore Einstein`; Title, Subject, Description, Keywords, and Language must be populated and synchronized between document info, root `/Lang`, and XMP where applicable.

## Prominent-Language Metadata Gate
Metadata must be written in the prominent language of the PDF. `/Lang`, XMP `dc:language`, Title, Subject, Description, and Keywords must match the document primary visible language unless a documented reason exists. Brand names may remain in brand form.

## Content-Specific Metadata Quality Gate
Description and Keywords must be content-specific and derived from the visible title, headings, first page, and substantive body content. Generic boilerplate fails unless the controlled fallback applies.

## Controlled Metadata Fallback
If a document cannot be confidently understood after reasonable inspection, use `Montefiore Einstein document - {Document Title}` for Description and `Montefiore Einstein, {Document Title}` for Keywords, localized where feasible. Document fallback use in the metadata audit.

## Native Text / Rasterization Gate
Native text must be preserved by default. If a source appears visually text-based but extraction fails, OCR may be used for diagnostics but not as an unreviewed substitute for native text. Image-only or raster-route text documents are review-required unless explicitly accepted.
