# Current PDF/UA Remediation Ruleset - ACO Code of Conduct Verified Package

This package follows the consolidated Montefiore Einstein PDF/UA ruleset currently in use. Key hard gates:

- Native text preservation by default for text-heavy documents.
- No full-page rasterization unless explicitly routed review-required/unfixable.
- Live AcroForm widgets preserved when present.
- Links/annotations preserved and supplied with required alternate descriptions/Contents.
- Meaningful images mapped to Figure structure elements with Alt text; decorative images artifacted or documented.
- Visual style, typography, tables, filled heading bands, rules/strokes, and meaningful visual assets compared against source.
- File-size growth investigated; production-final allowed only when growth is documented and justified by native-preserving requirements such as font embedding.
- Metadata completion gate: Author, Creator, Producer = Montefiore Einstein; Title, Subject, Description, Keywords, Language, and PDF/UA XMP identifier populated and audited.
- Handoff gate: PRODUCTION_FINAL requires veraPDF PASS, qpdf PASS, preservation gates, metadata gate, and visual QA.
