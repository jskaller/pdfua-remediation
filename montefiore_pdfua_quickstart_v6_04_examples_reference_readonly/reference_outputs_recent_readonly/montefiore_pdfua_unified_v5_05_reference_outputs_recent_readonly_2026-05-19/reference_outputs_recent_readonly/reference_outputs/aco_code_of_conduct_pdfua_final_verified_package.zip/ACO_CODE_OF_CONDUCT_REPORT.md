# ACO Code of Conduct PDF/UA Remediation Report

## Source

- File: `ACO_Code_of_Conduct_2020_(approved).pdf`
- Content: The Montefiore ACO Code of Conduct 2020, approved by the Board of Directors on March 6, 2020.

## Status

- Final status: `PRODUCTION_FINAL`
- veraPDF PDF/UA-1: PASS
- qpdf 12.3.2 --check: PASS

## Preservation Summary

- Page count: 11 -> 11
- Text words: 3958 -> 3958 (100.00%)
- Links: 2 -> 2
- Widgets: 0 -> 0
- Images: 1 -> 1
- Full-page rasterization: No
- OCR substitution: No

## Metadata

Metadata completion gate: PASS. Author, Creator, and Producer are `Montefiore Einstein`; language is `en-US`; Title, Subject, Description, and Keywords are populated from the document content.

## File Size

- Source size: 642,515 bytes
- Output size: 2,271,088 bytes
- Size ratio: 3.53x

The size ratio exceeds 2x, so the file-size gate was investigated. The increase is attributed to required font embedding needed for PDF/UA conformance. The absolute size remains modest, no raster fallback was used, and text/link/image/page/geometry gates pass.

## veraPDF fix note

After installing veraPDF 1.30.1, the prior candidate was corrected for heading nesting, link annotation Contents, and a fragile CIDSet/font validation issue. The final output now passes veraPDF PDF/UA-1.
