# Current PDF/UA Remediation Ruleset Addendum - Metadata Quality

## Content-Specific Metadata Quality Gate
Title, Subject, Description, and Keywords must be derived from the visible document title, first page, headings, body text, and document purpose. Generic descriptions or repeated boilerplate across unrelated files fail QA unless the controlled fallback rule applies.

## Controlled Metadata Fallback Rule
If, after reasonable inspection, the document purpose cannot be confidently determined because it is image-only, extremely sparse, ambiguous, truncated, technical, or otherwise not well understood, controlled fallback is allowed:

- Description: `Montefiore Einstein document - {Document Title}`
- Keywords: `Montefiore Einstein, {Document Title}`

The metadata audit must record `metadata_fallback_used`, `fallback_reason`, and `metadata_basis`.

## Fallback Abuse Gate
Fallback must not become the default. If more than a small minority of unrelated batch files use fallback metadata, pause and review.

## Metadata Completion Gate
Author, Creator, and Producer must be `Montefiore Einstein`. Title, Subject, Description, Keywords, and Language must be populated. Language must match the primary document language using a valid language tag. XMP and document information dictionary metadata must be synchronized where applicable.

## Metadata Audit Requirement
Every package must include `qa/metadata_audit.csv` showing required fields, specificity checks, fallback use, basis, XMP synchronization, qpdf status, veraPDF status, and overall pass/fail.
