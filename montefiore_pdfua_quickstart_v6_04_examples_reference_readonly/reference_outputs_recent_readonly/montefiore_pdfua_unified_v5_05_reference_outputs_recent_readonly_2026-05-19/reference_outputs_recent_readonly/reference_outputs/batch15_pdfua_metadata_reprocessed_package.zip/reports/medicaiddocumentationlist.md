# medicaiddocumentationlist.pdf

Status: `VERAPDF_PASS_REVIEW_REQUIRED`

Metadata-only reprocessing from prior batch 15 validated output.

- veraPDF PDF/UA-1: PASS
- qpdf --check: PASS
- Metadata gate: PASS
- Full-page rasterization: No
- OCR substitution: No
- Visual/content changes: No intentional changes

## Metadata

- Title: Medicaid Documentation Needed
- Author: Montefiore Einstein
- Creator: Montefiore Einstein
- Producer: Montefiore Einstein
- Language: en-US
- Subject: Bilingual Medicaid documentation checklist
- Description: Bilingual English and Spanish checklist of documents patients may need to bring for Medicaid-related assistance, including identity, residency, income, insurance, and support documentation.
- Keywords: Montefiore Einstein, Medicaid documentation, document checklist, bilingual, English, Spanish, identity documents, income proof, residency proof, insurance, patient financial assistance
- Fallback used: False
- Basis: Visible bilingual heading "MEDICAID DOCUMENTATION NEEDED / DOCUMENTOS NECESARIOS PARA EL MEDICAID" and lists of required documents.
