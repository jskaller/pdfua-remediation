# livingwill.pdf

Status: `VERAPDF_PASS_REVIEW_REQUIRED`

Metadata-only reprocessing from prior batch 15 validated output.

- veraPDF PDF/UA-1: PASS
- qpdf --check: PASS
- Metadata gate: PASS
- Full-page rasterization: No
- OCR substitution: No
- Visual/content changes: No intentional changes

## Metadata

- Title: Living Will
- Author: Montefiore Einstein
- Creator: Montefiore Einstein
- Producer: Montefiore Einstein
- Language: en-US
- Subject: Living will form for healthcare decisions and advance directives
- Description: Living will form for documenting medical care preferences, treatment decisions, and instructions to family, loved ones, and doctors if the patient cannot communicate decisions.
- Keywords: Montefiore Einstein, living will, advance directive, healthcare decisions, medical care preferences, end-of-life care, patient instructions, treatment choices
- Fallback used: False
- Basis: Visible title "Living Will" and form text directing family, loved ones, and doctors about treatment preferences if the signer cannot communicate medical decisions.
