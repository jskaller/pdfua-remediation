# headache diary.pdf

Status: `PRODUCTION_FINAL`

Metadata-only reprocessing from prior batch 15 validated output.

- veraPDF PDF/UA-1: PASS
- qpdf --check: PASS
- Metadata gate: PASS
- Full-page rasterization: No
- OCR substitution: No
- Visual/content changes: No intentional changes

## Metadata

- Title: Migraine Diary
- Author: Montefiore Einstein
- Creator: Montefiore Einstein
- Producer: Montefiore Einstein
- Language: en-US
- Subject: Montefiore migraine diary and headache tracking form
- Description: Migraine diary form for patients to record headache severity, triggers, symptoms, treatments, and related details to support care discussions with a clinician.
- Keywords: Montefiore Einstein, migraine diary, headache diary, headache tracking, patient form, migraine severity, triggers, symptoms, medication, doctor visit
- Fallback used: False
- Basis: Visible title "Migraine Diary" and instructions describing severity, triggers, symptoms, treatment, and bringing the diary to a doctor visit.
