# hotel-list-wa-sheet.pdf

Status: `VERAPDF_PASS_REVIEW_REQUIRED`

Metadata-only reprocessing from prior batch 15 validated output.

- veraPDF PDF/UA-1: PASS
- qpdf --check: PASS
- Metadata gate: PASS
- Full-page rasterization: No
- OCR substitution: No
- Visual/content changes: No intentional changes

## Metadata

- Title: Hotel List Worksheet
- Author: Montefiore Einstein
- Creator: Montefiore Einstein
- Producer: Montefiore Einstein
- Language: en-US
- Subject: Montefiore hotel accommodation and visitor lodging worksheet
- Description: Hotel accommodation worksheet listing lodging options, commute details, room rates, taxes, parking, breakfast, amenities, and visitor preferences for Montefiore-related travel.
- Keywords: Montefiore Einstein, hotel list, lodging worksheet, accommodations, commute, room rates, parking, breakfast, amenities, visitor travel
- Fallback used: False
- Basis: Visible table headings and entries for hotel address, commute to Montefiore, room rates, taxes, parking, breakfast, amenities, and preferences.
