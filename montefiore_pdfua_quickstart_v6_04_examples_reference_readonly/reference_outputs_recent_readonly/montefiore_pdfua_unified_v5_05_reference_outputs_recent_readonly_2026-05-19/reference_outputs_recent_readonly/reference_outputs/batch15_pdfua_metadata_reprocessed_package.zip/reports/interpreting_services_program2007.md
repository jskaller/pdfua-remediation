# interpreting_services_program2007.pdf

Status: `VERAPDF_PASS_REVIEW_REQUIRED`

Metadata-only reprocessing from prior batch 15 validated output.

- veraPDF PDF/UA-1: PASS
- qpdf --check: PASS
- Metadata gate: PASS
- Full-page rasterization: No
- OCR substitution: No
- Visual/content changes: No intentional changes

## Metadata

- Title: Interpreting Services Program
- Author: Montefiore Einstein
- Creator: Montefiore Einstein
- Producer: Montefiore Einstein
- Language: en-US
- Subject: Montefiore interpreting and language assistance services program
- Description: Program document describing Montefiore interpreting services and communication assistance for deaf, hard of hearing, deafblind, and limited English proficient patients and families.
- Keywords: Montefiore Einstein, interpreting services, interpreter program, language assistance, deaf, hard of hearing, deafblind, limited English proficient, patient communication, access services
- Fallback used: False
- Basis: Visible title "Interpreting Services Program" and page text identifying served groups including deaf, hard of hearing, deafblind, and language assistance users.
