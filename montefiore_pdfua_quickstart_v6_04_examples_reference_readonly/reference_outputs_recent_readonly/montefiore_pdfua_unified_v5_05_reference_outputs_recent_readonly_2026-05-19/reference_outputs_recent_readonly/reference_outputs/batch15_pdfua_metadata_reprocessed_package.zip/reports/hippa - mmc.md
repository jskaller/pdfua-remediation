# hippa - mmc.pdf

Status: `PRODUCTION_FINAL`

Metadata-only reprocessing from prior batch 15 validated output.

- veraPDF PDF/UA-1: PASS
- qpdf --check: PASS
- Metadata gate: PASS
- Full-page rasterization: No
- OCR substitution: No
- Visual/content changes: No intentional changes

## Metadata

- Title: Summary of Your Privacy Rights
- Author: Montefiore Einstein
- Creator: Montefiore Einstein
- Producer: Montefiore Einstein
- Language: en-US
- Subject: Montefiore patient privacy rights and medical information practices
- Description: Summary describing patient privacy rights and Montefiore responsibilities for protecting, using, and disclosing medical information, with reference to the Notice of Privacy Practices.
- Keywords: Montefiore Einstein, Montefiore, HIPAA, privacy rights, medical information, patient privacy, notice of privacy practices, protected health information, PHI
- Fallback used: False
- Basis: Visible heading "Summary of Your Privacy Rights" and body text explaining uses and disclosures of health information.
