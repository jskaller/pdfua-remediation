# map of inside mmc.pdf

Status: `PRODUCTION_FINAL`

Metadata-only reprocessing from prior batch 15 validated output.

- veraPDF PDF/UA-1: PASS
- qpdf --check: PASS
- Metadata gate: PASS
- Full-page rasterization: No
- OCR substitution: No
- Visual/content changes: No intentional changes

## Metadata

- Title: Map of Inside MMC
- Author: Montefiore Einstein
- Creator: Montefiore Einstein
- Producer: Montefiore Einstein
- Language: en-US
- Subject: Interior map and wayfinding document for Montefiore Medical Center
- Description: Montefiore Einstein document - Map of Inside MMC
- Keywords: Montefiore Einstein, Map of Inside MMC
- Fallback used: True
- Basis: Sparse/primarily visual map document; title derived from filename because text extraction does not provide enough reliable descriptive content.
