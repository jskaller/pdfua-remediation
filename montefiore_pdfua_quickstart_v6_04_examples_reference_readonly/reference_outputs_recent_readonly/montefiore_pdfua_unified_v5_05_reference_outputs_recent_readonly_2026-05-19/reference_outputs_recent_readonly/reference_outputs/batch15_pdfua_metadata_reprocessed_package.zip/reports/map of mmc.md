# map of mmc.pdf

Status: `PRODUCTION_FINAL`

Metadata-only reprocessing from prior batch 15 validated output.

- veraPDF PDF/UA-1: PASS
- qpdf --check: PASS
- Metadata gate: PASS
- Full-page rasterization: No
- OCR substitution: No
- Visual/content changes: No intentional changes

## Metadata

- Title: Map of MMC
- Author: Montefiore Einstein
- Creator: Montefiore Einstein
- Producer: Montefiore Einstein
- Language: en-US
- Subject: Montefiore Medical Center map and wayfinding document
- Description: Montefiore Einstein document - Map of MMC
- Keywords: Montefiore Einstein, Map of MMC
- Fallback used: True
- Basis: Sparse/primarily visual Montefiore Medical Center map; title derived from filename and visible Montefiore Medical Center heading.
