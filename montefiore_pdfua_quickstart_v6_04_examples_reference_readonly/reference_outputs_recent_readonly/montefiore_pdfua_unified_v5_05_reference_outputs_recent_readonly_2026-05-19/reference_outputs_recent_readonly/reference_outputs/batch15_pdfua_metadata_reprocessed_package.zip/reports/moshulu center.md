# moshulu center.pdf

Status: `PRODUCTION_FINAL`

Metadata-only reprocessing from prior batch 15 validated output.

- veraPDF PDF/UA-1: PASS
- qpdf --check: PASS
- Metadata gate: PASS
- Full-page rasterization: No
- OCR substitution: No
- Visual/content changes: No intentional changes

## Metadata

- Title: Mosholu Montefiore Community Center Weight and Fitness Center
- Author: Montefiore Einstein
- Creator: Montefiore Einstein
- Producer: Montefiore Einstein
- Language: en-US
- Subject: Mosholu Montefiore Community Center weight and fitness center flyer
- Description: Flyer for the Mosholu Montefiore Community Center Weight and Fitness Center describing hours, exercise equipment, locker options, guest passes, and membership rates.
- Keywords: Montefiore Einstein, Mosholu Montefiore Community Center, weight and fitness center, employee fitness, exercise equipment, membership rates, guest pass, lockers, fitness flyer
- Fallback used: False
- Basis: Visible flyer text identifying the Weight and Fitness Center, hours, equipment, guest passes, lockers, and rates.
