# Batch 13 targeted size repair report

## Summary
- Files reprocessed: 3
- veraPDF PDF/UA-1: 3/3 PASS
- qpdf 12.3.2 --check: 3/3 PASS
- PRODUCTION_FINAL: 0
- VERAPDF_PASS_REVIEW_REQUIRED: 3

## File results
- `Questionnaire-Center-for-the-Aging-Brain.pdf` - `VERAPDF_PASS_REVIEW_REQUIRED`; size 6,037,253 -> 455,049 bytes; veraPDF PASS; qpdf PASS. Reason: Source has no extractable native text and consists of scanned page images. Reprocessed output preserves the original bitonal scanned page images and avoids RGB re-raster inflation, but remains review-required under the native-text gate.
- `Required_Public_Disclosure_for_the_Next_Generation_ACO_Participation_Waiver_06132019.pdf` - `VERAPDF_PASS_REVIEW_REQUIRED`; size 2,913,772 -> 930,871 bytes; veraPDF PASS; qpdf PASS. Reason: Reprocessed output preserves native page content and reduces size substantially, but required font embedding increases size above the 2x growth gate and render comparison shows glyph-level/font-substitution differences; visual review is required.
- `Spanish-Caregiver-Resource-Guide.pdf` - `VERAPDF_PASS_REVIEW_REQUIRED`; size 22,691,237 -> 3,164,723 bytes; veraPDF PASS; qpdf PASS. Reason: Reprocessed output preserves original native page content, original links, and original assets with major size reduction. It uses a page-level Figure/ActualText structure route rather than granular paragraph/list/table tagging, so it remains review-required under the semantic tagging guardrail.

## Text/rasterization handoff note
The repair route did not create new full-page raster replacements. For Spanish and Questionnaire the source visual content/assets are byte-level/native preserved in rendering; Required Disclosure required font embedding to satisfy PDF/UA font rules, which explains its remaining size growth and visual-review status.
