# Current PDF/UA Remediation Ruleset Addendum - Batch 13 Size Repair

## File Size / Asset Inflation Gate
For every remediated PDF, compare original and output file size. If the output is greater than 2x the source, more than 5 MB larger than the source, greater than 10 MB when the source was not already image-heavy, or greater than 15 MB absolute without documented justification, QA fails pending investigation. Any output greater than 20 MB must be reworked or routed review-required unless the source was already comparable in size and the increase is explained by required native-preserving fixes.

For size-gate breaches, run an object-level/asset audit of images, streams, duplicate assets, compression, dimensions, effective DPI, fonts, links, widgets, and text coverage. Production-final is forbidden when the increase is caused by avoidable full-page rasterization, high-DPI overlays, duplicated image assets, unnecessary PNG/RGB conversion, page screenshot replacement, or failure to reuse original assets.

## Native Text Preservation Gate
For text-heavy, form-like, directory-like, policy-like, schedule-like, application-like, and official documents, native text must be preserved by default. If the source has extractable text, the output must retain a high text-coverage ratio. If the source is visually text-based but extraction fails, OCR may be used for diagnostics, but OCR text must not be treated as a production-final substitute for preserving native text. Raster fallback or page-level semantic fallback must be review-required, not production-final.

## Visual Style / Graphic Furniture Gate
Bold, underlined, boxed, tabular, heading, rule, line, footer, header, banner, logo, and other visual-furniture styles must be compared against the source. Missing, darkened, thickened, softened, shifted, or degraded visual furniture fails production-final.

## Handoff Gate
No file may be handed off as PRODUCTION_FINAL unless veraPDF passes, qpdf passes, expected native text is preserved, expected widgets/forms are preserved, expected links/annotations are preserved, visual comparison passes, and file-size gates pass. Review-required PDFs must be clearly identified and not mixed into a final-looking package.
