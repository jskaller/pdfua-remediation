# Questionnaire-Center-for-the-Aging-Brain.pdf - repair report

**Status:** `VERAPDF_PASS_REVIEW_REQUIRED`

## Reason
Source has no extractable native text and consists of scanned page images. Reprocessed output preserves the original bitonal scanned page images and avoids RGB re-raster inflation, but remains review-required under the native-text gate.

## Validation
- veraPDF PDF/UA-1: PASS
- qpdf 12.3.2 --check: PASS
- Page count: 17 -> 17
- Widgets: 0 -> 0
- Links: 0 -> 0

## Size gate
- Original: 458,584 bytes
- Prior rendered output: 6,037,253 bytes (13.165x original)
- Reprocessed output: 455,049 bytes (0.992x original)
- Saved vs prior output: 5,582,204 bytes

## Text handling / rasterization
- Full-page re-rasterization: No new full-page raster replacement was used.
- Original visual page content/assets were preserved from the source.
- OCR substitution: No OCR text was used as a replacement for native visual content.
- Text chars: 0 -> 1,954

## Visual QA
- Render comparison: PASS
- Notes: Exact render match at 72 dpi.
