# Required_Public_Disclosure_for_the_Next_Generation_ACO_Participation_Waiver_06132019.pdf - repair report

**Status:** `VERAPDF_PASS_REVIEW_REQUIRED`

## Reason
Reprocessed output preserves native page content and reduces size substantially, but required font embedding increases size above the 2x growth gate and render comparison shows glyph-level/font-substitution differences; visual review is required.

## Validation
- veraPDF PDF/UA-1: PASS
- qpdf 12.3.2 --check: PASS
- Page count: 4 -> 4
- Widgets: 0 -> 0
- Links: 0 -> 0

## Size gate
- Original: 91,471 bytes
- Prior rendered output: 2,913,772 bytes (31.855x original)
- Reprocessed output: 930,871 bytes (10.177x original)
- Saved vs prior output: 1,982,901 bytes

## Text handling / rasterization
- Full-page re-rasterization: No new full-page raster replacement was used.
- Original visual page content/assets were preserved from the source.
- OCR substitution: No OCR text was used as a replacement for native visual content.
- Text chars: 13,242 -> 12,592

## Visual QA
- Render comparison: REVIEW
- Notes: Render diff samples included; changes are primarily font/glyph-level after required font embedding.
