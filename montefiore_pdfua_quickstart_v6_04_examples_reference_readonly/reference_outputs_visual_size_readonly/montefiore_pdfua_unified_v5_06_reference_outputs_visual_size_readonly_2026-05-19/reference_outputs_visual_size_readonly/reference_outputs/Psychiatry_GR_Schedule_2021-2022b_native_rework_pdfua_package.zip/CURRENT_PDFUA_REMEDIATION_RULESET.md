# Updated PDF/UA Remediation Ruleset - Rework 2

## Native-preserving first
Preserve original text operators, images, vector graphics, page geometry, links, annotations, forms, and layout wherever technically possible. Do not use full-page rasterization for mixed text/image documents unless no safe native-preserving route is available.

## Native Text Preservation Gate
For any source that is text-heavy, form-like, directory-like, policy-like, schedule-like, application-like, or otherwise document-first:
- Native text must be preserved by default.
- If the source has extractable text, the output must retain a high text-coverage ratio.
- If the source appears visually text-based but extraction fails, OCR may be run for diagnostics; OCR text must not substitute for preserving native text unless explicitly routed as review-required.
- If the output has zero or materially reduced parsed text, it cannot be PRODUCTION_FINAL.
- If raster fallback is used, status must be VERAPDF_PASS_REVIEW_REQUIRED or UNFIXABLE_WITH_CURRENT_ROUTE, never production-final.

## Visual Style Preservation Gate
For forms and official documents, bold, underlined, boxed, tabular, and heading styles must be compared visually against the source. Missing bold headings/labels, missing rules/lines, softened text, degraded text crispness, degraded logos/banners, or changed visual hierarchy fail production-final.

## Meaningful Visual Asset Preservation Gate
For logos, banners, mastheads, hero images, cover artwork, diagrams, charts, maps, clinical/marketing photos, and other meaningful visual assets, preserve original source assets/content wherever technically possible. Do not redraw, downsample, recompress, substitute, or rasterize these regions unless no native-preserving route is available. Visible degradation, softness, color shift, positioning drift, or reconstruction artifacts fail QA.

## Graphic Line / Stroke Preservation Gate
For official documents, forms, schedules, directories, applications, policies, branded documents, and table-like PDFs, horizontal and vertical rules, separator lines, borders, boxes, underlines, table rules, footer rules, header rules, and branded divider lines must preserve source appearance. Stroke thickness, color, length, position, and visual weight must be compared against the source render. Thick black replacements for thin gray/blue source rules are a production-final failure. Missing, added, shifted, darkened, thickened, or softened lines fail QA unless explicitly routed as review-required.

## Whole-Page Visual Furniture QA
Before handoff, do not inspect only the user-reported region. Generate and review full-page source/output renders plus targeted crops for page-1 header/banner, body heading/rules, table/header rows, footer/contact block, and all prominent horizontal/vertical rules. Any prominent line, rule, bar, logo, or branded-furniture mismatch fails production-final.

## Live AcroForm Widget Preservation Gate
If the source PDF has live AcroForm widgets, the output must preserve live widgets. If source widget count > 0 and output widget count is 0, handoff fails unless the user explicitly requested flattening or the file is labeled diagnostic/unfixable. A veraPDF-pass form fallback that sacrifices native text is review-required, not production-final.

## Batch / Package Handoff Gate
No file may be marked PRODUCTION_FINAL unless veraPDF PASS, qpdf PASS, expected native text preserved, expected widgets/forms preserved, expected links/annotations preserved where applicable, visual comparison passes, and file-size/preservation gate passes. No known failing or review-required PDF may be mixed into a final package without being clearly separated and named as review-required.

## Metadata Rule
Author, Creator, and Producer must be Montefiore Einstein. If missing, derive Keywords from content, and derive Subject/Description from title, first page, and/or document content.
