# Single PDF/UA Rework Report - Psychiatry_GR_Schedule_2021-2022(b).pdf

## Status

**PRODUCTION_FINAL**

This rework uses a native source-preserving patch rather than a rebuilt or rasterized page. The original source visual content, including the page 1 Montefiore/Einstein banner and the thin footer/header rules, is preserved.

## Validation

- veraPDF PDF/UA-1: PASS
- qpdf 12.3.2 `--check`: PASS
- Page count: 4 -> 4
- Page geometry: preserved
- Source widgets/output widgets: 0 / 0
- Source links/output links: 0 / 0

## Text handling / rasterization

- Route: native source-preserving PDF patch
- Full-page rasterization: No
- Targeted raster overlays: No
- Source extracted words: 485
- Output extracted words: 485
- Text coverage ratio: 1.0000

Native text is retained. OCR was not used as a substitute for native text.

## Visual preservation

- Page 1 banner/logo area: PASS - original source visual content preserved; no redrawn/reconstructed banner.
- Page 1 bottom/footer rule: PASS - original thin blue/gray rule preserved; no thick black replacement bar.
- Header/body/footer visual furniture: PASS by full-page render and targeted crop review.
- Page render comparison: pages 2-4 unchanged; page 1 has only a tiny renderer-detected difference (0.140260 mean absolute diff in the full-page crop set) attributable to font embedding/metadata patching, not layout reconstruction.

## Changes made

- Added PDF/UA XMP identification metadata and required document metadata.
- Added table header scope attributes to existing source structure tags.
- Embedded replacement TrueType font programs for originally unembedded TimesNewRomanPSMT, ArialMT, and Arial-BoldMT to satisfy PDF/UA font embedding requirements.
- Did not rebuild the page, redraw lines, redraw logos, replace source assets, or rasterize the document.

## File-size gate

- Source size: 160105 bytes
- Output size: 994828 bytes

The size increase was reviewed and is due to embedding three TrueType font programs required for PDF/UA, not rasterization or image recompression.
