# PDF/UA Remediation Ruleset Addendum - Typography Fidelity

## Typography Fidelity Gate for Native Rebuilds
For any native text rebuild, especially directories, forms, schedules, tables, policies, disclosures, applications, and official documents, QA must compare source and output typography on sampled pages. The comparison must include:

- apparent font family / typeface match,
- font weight and darkness,
- italic/oblique styling,
- heading emphasis,
- line spacing,
- text density,
- visual hierarchy and readability.

Missing italic/oblique styling on meaningful headings, materially heavier/lighter body text, or changed text density must be documented. If the typography change affects readability, visual hierarchy, or brand/document fidelity, the file cannot be marked `PRODUCTION_FINAL`; it must be reworked or routed `VERAPDF_PASS_REVIEW_REQUIRED`.

## Directory Header Typography Gate
Directory section headers must preserve not only the header text and filled background bars, but also heading typography, including italic/oblique appearance, weight, color, placement, and alignment. A restored header with the wrong type style is review-required unless no better font-matching route is practical.

## Rebuild Font Selection Gate
For reconstructed live-text outputs, generic default fonts are not acceptable when a closer installed font family is available. Font substitution must be chosen to approximate the source. For Arial-like source material, use Arial-compatible metric fonts when available. If the source extraction labels body text as bold but the rendered original appears visually lighter, select the replacement font by rendered appearance, not extraction labels alone.

## Typography Sampling QA
For long rebuilt documents, sample at least page 1, page 2, every 50th/100th page as appropriate, and the final page. Include targeted crops for:

- first-page section headers,
- body/provider rows or equivalent repeated body pattern,
- any reverse-text or filled-header regions,
- representative mid-document pages,
- final-page footer/header regions.

Known typography deviations must be described in the handoff and per-file report.
