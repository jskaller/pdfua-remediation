# dc_aco_ip_directory_11-9-2020.pdf - Typography Rework Report

## Status

`VERAPDF_PASS_REVIEW_REQUIRED`

The file passes veraPDF PDF/UA-1 and qpdf, preserves page count, geometry, text coverage, and avoids raster/OCR substitution. It remains review-required because the successful route is a native live-text rebuild rather than a direct source-object patch.

## Reason for this pass

A prior repair restored the white-text black-background directory section headers, but the section headers did not sufficiently preserve the source's italic/oblique appearance and the overall rebuilt body type appeared heavier than the original.

This rework updates the native rebuild typography:

- Uses Arimo, an Arial-compatible font family, instead of DejaVu Sans.
- Renders reverse/filled directory section headers in bold italic.
- Uses lighter regular body text where the source extraction reported `Arial-BoldMT` but the rendered source appears visually lighter.
- Preserves bold italic institution/location-heading style where present.

## Validation

- veraPDF PDF/UA-1: PASS
- qpdf 12.3.2 `--check`: PASS
- Page count: 525 -> 525
- Page geometry: preserved
- Text coverage: 261,036 / 261,036 words = 100%
- Source size: 2,797,909 bytes
- Output size: 1,378,206 bytes
- Widgets: 0 -> 0
- Links: 0 -> 0
- Images: 0 -> 0

## Text handling / rasterization

- Full-page rasterization: No
- OCR substitution: No
- Native live-text rebuild: Yes
- Output text remains live/selectable.

## Typography QA

Targeted crops are included for:

- page 1 section headers (`source_p001_section_headers_typography_crop.png`, `output_p001_section_headers_typography_crop.png`)
- page 1 repeated body/provider pattern (`source_p001_body_typography_crop.png`, `output_p001_body_typography_crop.png`)

The section headers now preserve the white-on-dark filled header treatment with italic/oblique styling, and the body text is visually lighter than the prior repair.

## Remaining review note

The file is still routed `VERAPDF_PASS_REVIEW_REQUIRED` because it is a full 525-page native reconstruction. Even with improved typography, this route should receive human spot review before final production acceptance.
