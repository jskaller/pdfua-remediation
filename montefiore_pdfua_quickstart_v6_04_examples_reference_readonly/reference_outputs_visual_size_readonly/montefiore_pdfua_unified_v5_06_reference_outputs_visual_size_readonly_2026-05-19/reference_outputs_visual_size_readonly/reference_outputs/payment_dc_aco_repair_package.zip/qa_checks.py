import fitz, json, os, hashlib, csv
from pathlib import Path
from PIL import Image, ImageChops, ImageStat
base=Path('/mnt/data/rework_payment_dc')
files={
 'Payment Rule Waivers-NG ACO Website 2017':('/mnt/data/Payment Rule Waivers-NG ACO Website 2017.pdf', str(base/'output_files/PRODUCTION_FINAL/Payment Rule Waivers-NG ACO Website 2017.pdf')),
 'dc_aco_ip_directory_11-9-2020':('/mnt/data/dc_aco_ip_directory_11-9-2020(1).pdf', str(base/'output_files/VERAPDF_PASS_REVIEW_REQUIRED/dc_aco_ip_directory_11-9-2020.pdf'))
}
(base/'qa/renders').mkdir(exist_ok=True)
summary=[]
for name,(src,out) in files.items():
    ds=fitz.open(src); do=fitz.open(out)
    sw=sum(len(p.get_text('words')) for p in ds); ow=sum(len(p.get_text('words')) for p in do)
    rects_src=sum(len(p.get_drawings()) for p in ds)
    rects_out=sum(len(p.get_drawings()) for p in do)
    summary.append({'file':name+'.pdf','source_pages':len(ds),'output_pages':len(do),'source_words':sw,'output_words':ow,'text_coverage_ratio':round(ow/sw,6) if sw else None,'source_size':os.path.getsize(src),'output_size':os.path.getsize(out),'source_drawings':rects_src,'output_drawings':rects_out})
    sample_pages=[0] if len(ds)==1 else [0,1,49,99,199,299,399,499,524]
    for pno in sample_pages:
        if pno>=len(ds): continue
        for label,doc in [('source',ds),('output',do)]:
            pix=doc[pno].get_pixmap(matrix=fitz.Matrix(1.5,1.5), alpha=False)
            pix.save(str(base/f'qa/renders/{name}_{label}_page_{pno+1:03d}.png'))
    if name.startswith('Payment'):
        # header/table crop
        for label,doc in [('source',ds),('output',do)]:
            pix=doc[0].get_pixmap(matrix=fitz.Matrix(3,3), clip=fitz.Rect(60,120,555,180), alpha=False)
            pix.save(str(base/f'qa/{name}_{label}_table_header_crop.png'))
    if name.startswith('dc_aco'):
        for label,doc in [('source',ds),('output',do)]:
            pix=doc[0].get_pixmap(matrix=fitz.Matrix(3,3), clip=fitz.Rect(40,40,565,75), alpha=False)
            pix.save(str(base/f'qa/{name}_{label}_section_header_crop_p001.png'))
(base/'qa/metrics_summary.json').write_text(json.dumps(summary,indent=2))
with open(base/'qa/size_text_visual_summary.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=summary[0].keys()); w.writeheader(); w.writerows(summary)
print(json.dumps(summary,indent=2))
