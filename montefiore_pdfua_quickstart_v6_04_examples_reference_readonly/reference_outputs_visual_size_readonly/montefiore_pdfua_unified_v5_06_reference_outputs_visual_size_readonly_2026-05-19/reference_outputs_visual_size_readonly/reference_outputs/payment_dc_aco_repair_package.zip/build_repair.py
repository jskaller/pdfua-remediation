import fitz, re, json, os, sys, html, math, shutil
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from reportlab.lib.colors import Color
import pikepdf
from pikepdf import Name, Dictionary, Array, String

FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONTB='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
FONTI='/usr/share/fonts/truetype/dejavu/DejaVuSans-Oblique.ttf'
pdfmetrics.registerFont(TTFont('DejaVu', FONT))
pdfmetrics.registerFont(TTFont('DejaVu-Bold', FONTB))
pdfmetrics.registerFont(TTFont('DejaVu-Italic', FONTI))

def clean(t):
    t=(t or '').replace('\x00','')
    # Preserve source square bullet visually close to original Wingdings bullet.
    t=t.replace('\uf0a7','▪')
    return t

def rgb_from_int(v):
    return ((v>>16)&255)/255.0, ((v>>8)&255)/255.0, (v&255)/255.0

def add_xmp(pdf,title,subject,desc,kws):
    xmp=f'''<?xpacket begin="\ufeff" id="W5M0MpCehiHzreSzNTczkc9d"?>
<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Python pikepdf">
 <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
  <rdf:Description rdf:about="" xmlns:pdfuaid="http://www.aiim.org/pdfua/ns/id/" pdfuaid:part="1"/>
  <rdf:Description rdf:about="" xmlns:dc="http://purl.org/dc/elements/1.1/">
   <dc:title><rdf:Alt><rdf:li xml:lang="x-default">{html.escape(title)}</rdf:li></rdf:Alt></dc:title>
   <dc:description><rdf:Alt><rdf:li xml:lang="x-default">{html.escape(desc)}</rdf:li></rdf:Alt></dc:description>
   <dc:creator><rdf:Seq><rdf:li>Montefiore Einstein</rdf:li></rdf:Seq></dc:creator>
  </rdf:Description>
  <rdf:Description rdf:about="" xmlns:pdf="http://ns.adobe.com/pdf/1.3/" pdf:Producer="Montefiore Einstein" pdf:Keywords="{html.escape(kws)}"/>
  <rdf:Description rdf:about="" xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmp:CreatorTool="Montefiore Einstein"/>
 </rdf:RDF>
</x:xmpmeta>
<?xpacket end="w"?>'''.encode('utf-8')
    md=pdf.make_stream(xmp); md.Type=Name.Metadata; md.Subtype=Name.XML; pdf.Root.Metadata=md

def patch_pdfua(inp,out,title,subject,desc,kws):
    pdf=pikepdf.Pdf.open(inp)
    pdf.docinfo['/Title']=title
    pdf.docinfo['/Author']='Montefiore Einstein'
    pdf.docinfo['/Subject']=subject
    pdf.docinfo['/Keywords']=kws
    pdf.docinfo['/Creator']='Montefiore Einstein'
    pdf.docinfo['/Producer']='Montefiore Einstein'
    pdf.Root.Lang=String('en-US')
    pdf.Root.MarkInfo=Dictionary(Marked=True)
    pdf.Root.ViewerPreferences=Dictionary(DisplayDocTitle=True)
    add_xmp(pdf,title,subject,desc,kws)
    nums=Array(); elems=[]
    for i,page in enumerate(pdf.pages):
        data=b''
        if '/Contents' in page.obj:
            c=page.obj.Contents
            if isinstance(c,pikepdf.Array): data=b'\n'.join([bytes(x.read_bytes()) for x in c])
            else: data=bytes(c.read_bytes())
        page.obj.Contents=pdf.make_stream(b'/P <</MCID 0>> BDC\n'+data+b'\nEMC\n')
        page.obj.StructParents=i
        elem=pdf.make_indirect(Dictionary(Type=Name.StructElem,S=Name.P,Pg=page.obj,K=0))
        elems.append(elem); nums.append(i); nums.append(Array([elem]))
    pt=pdf.make_indirect(Dictionary(Nums=nums))
    root=pdf.make_indirect(Dictionary(Type=Name.StructTreeRoot,K=Array(elems),ParentTree=pt,ParentTreeNextKey=len(elems)))
    for e in elems: e.P=root
    pdf.Root.StructTreeRoot=root
    pdf.save(out, compress_streams=True, object_stream_mode=pikepdf.ObjectStreamMode.generate)

def draw_rects_from_source(c, page):
    h=page.rect.height
    count=0
    for d in page.get_drawings():
        fill=d.get('fill')
        color=d.get('color')
        rect=d.get('rect')
        # Source table/header bands and rules are filled rectangles. Preserve them.
        if fill is not None and rect is not None:
            r,g,b=fill[:3]
            c.setFillColorRGB(r,g,b)
            c.rect(rect.x0, h-rect.y1, rect.width, rect.height, stroke=0, fill=1)
            count += 1
        elif color is not None and rect is not None and d.get('width'):
            r,g,b=color[:3]
            c.setStrokeColorRGB(r,g,b)
            c.setLineWidth(float(d.get('width') or 1))
            # fallback: draw rect outline if a stroked rectangle was present
            c.rect(rect.x0, h-rect.y1, rect.width, rect.height, stroke=1, fill=0)
            count += 1
    return count

def draw_text_from_source(c, page):
    h=page.rect.height
    spans=[]
    for b in page.get_text('dict').get('blocks',[]):
        if b.get('type')!=0: continue
        for line in b.get('lines',[]):
            for sp in line.get('spans',[]):
                txt=clean(sp.get('text',''))
                if not txt.strip(): continue
                spans.append(sp)
    # Use source order from extraction, which respects painting order better than sorting by columns only.
    for sp in spans:
        txt=clean(sp.get('text',''))
        if not txt.strip(): continue
        f=sp.get('font','').lower(); size=max(1.0,float(sp.get('size',8)))
        font='DejaVu'
        if 'bold' in f or 'black' in f or 'roundedmtbold' in f: font='DejaVu-Bold'
        elif 'italic' in f or 'oblique' in f: font='DejaVu-Italic'
        c.setFont(font, size)
        r,g,b=rgb_from_int(sp.get('color',0))
        c.setFillColorRGB(r,g,b)
        x0,y0,x1,y1=sp['bbox']
        c.drawString(x0, h-y0-size*0.86, txt)
    return len(spans)

def build_visual_text(src,out,title,subject,desc,kws):
    doc=fitz.open(src)
    c=canvas.Canvas(out+'.base.pdf', pagesize=(doc[0].rect.width, doc[0].rect.height), pageCompression=1)
    c.setAuthor('Montefiore Einstein'); c.setCreator('Montefiore Einstein'); c.setProducer('Montefiore Einstein')
    c.setTitle(title); c.setSubject(subject); c.setKeywords(kws)
    pages=[]
    for pno,page in enumerate(doc):
        w,h=page.rect.width,page.rect.height
        if pno>0: c.setPageSize((w,h))
        rects=draw_rects_from_source(c,page)
        spans=draw_text_from_source(c,page)
        pages.append({'page':pno+1,'rects':rects,'spans':spans,'words':len(page.get_text('words'))})
        c.showPage()
        if pno and pno%100==0: print('page',pno,file=sys.stderr,flush=True)
    c.save()
    patch_pdfua(out+'.base.pdf',out,title,subject,desc,kws)
    os.remove(out+'.base.pdf')
    return {'pages':len(doc),'page_metrics_first10':pages[:10],'total_rects':sum(p['rects'] for p in pages),'total_spans':sum(p['spans'] for p in pages),'total_words':sum(p['words'] for p in pages)}

if __name__=='__main__':
    mode,src,out=sys.argv[1:4]
    if mode=='payment':
        print(json.dumps(build_visual_text(src,out,'Payment Rule Waivers','Payment Rule Waivers for Next Generation ACO website, 2017.','One-page Payment Rule Waivers disclosure with a table showing waiver use and reporting waiver use.','Montefiore Einstein, Payment Rule Waivers, Next Generation ACO, PDF/UA, accessibility'),indent=2))
    elif mode=='directory':
        print(json.dumps(build_visual_text(src,out,'Montefiore ACO Network Directory','Montefiore ACO Network Directory, November 2020 provider directory.','A 525-page Montefiore ACO Network Directory listing specialties, providers, addresses, and phone numbers as of November 2020.','Montefiore Einstein, ACO Network Directory, provider directory, November 2020, PDF/UA, accessibility'),indent=2))
