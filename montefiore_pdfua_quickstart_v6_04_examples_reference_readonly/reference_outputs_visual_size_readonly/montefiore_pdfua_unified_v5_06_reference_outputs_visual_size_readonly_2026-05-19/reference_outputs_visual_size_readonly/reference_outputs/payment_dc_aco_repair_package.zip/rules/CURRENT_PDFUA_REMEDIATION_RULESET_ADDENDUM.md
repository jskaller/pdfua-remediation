# PDF/UA Remediation Ruleset Addendum - Table/Fill/Directory Header Gates

## Table / Background Fill Preservation Gate
For any source with table-like layout, colored header bands, shaded cells, boxed content, or visible row/column structure, the output must preserve the visual table structure. Header background fills, cell boundaries, alignment, spacing, and table grouping must match the source closely. If a colored table header or shaded cell is omitted, changed, flattened into plain text, or visually reinterpreted, QA fails. Text-only preservation is insufficient for PRODUCTION_FINAL.

## Directory Section Header Preservation Gate
For directory-like, schedule-like, catalog-like, or provider-list documents, section headers are mandatory structural and visual elements. The remediation must preserve both the header text and its visual treatment, including background fills, reverse/white text, column placement, and spacing. Missing, restyled, or visually de-emphasized section headers fail QA even if overall text coverage is high.

## Reverse Text / Filled Heading Gate
Text rendered in white or light color over dark fills, colored bands, or heading blocks must be explicitly checked during visual QA. Extraction/rebuild workflows must not drop the background fill, alter the text color, or convert the heading into ordinary body text. These elements must be included in targeted render comparisons.

## Visual Region Sampling Gate for Rebuilds
When a file is rebuilt from extracted text, QA must include targeted crops for meaningful visual furniture: table headers, filled heading bands, reverse text, specialty/section headers, footer/header rules, and all regions that convey document hierarchy. A successful veraPDF/qpdf pass and high text coverage are not sufficient if these regions fail visual comparison.
