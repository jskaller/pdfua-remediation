# Targeted PDF/UA Repair Report - Payment Rule Waivers and DC ACO Directory

## Summary
- Files reprocessed: 2
- veraPDF PDF/UA-1: 2 / 2 PASS
- qpdf 12.3.2 --check: 2 / 2 PASS
- PRODUCTION_FINAL: 1
- VERAPDF_PASS_REVIEW_REQUIRED: 1

## Results

### Payment Rule Waivers-NG ACO Website 2017.pdf
Status: PRODUCTION_FINAL

Reworked to preserve the source's one-row table layout, including the blue background header, white header text, borders, and column alignment. Live/selectable text was preserved. No full-page rasterization or OCR substitution was used.

### dc_aco_ip_directory_11-9-2020.pdf
Status: VERAPDF_PASS_REVIEW_REQUIRED

Reworked to preserve directory section headers, including reverse white text on dark filled backgrounds such as Addiction Medicine and Addiction Psychiatry on page 1. Live/selectable text and page count were preserved. No full-page rasterization or OCR substitution was used. This remains review-required because the successful route is a native live-text rebuild rather than a direct source-object patch.

## Ruleset changes added
- Table / Background Fill Preservation Gate
- Directory Section Header Preservation Gate
- Reverse Text / Filled Heading Gate
- Visual Region Sampling Gate for Rebuilds

## Text handling and rasterization
- Full-page rasterization: No
- OCR substitution: No
- Native/live text: Yes
- Text coverage:
  - Payment Rule Waivers: 49 / 49 words, 100%
  - DC ACO Directory: 261,036 / 261,036 words, 100%

## Visual QA artifacts
The package includes targeted source/output crops for:
- Payment table header region
- DC ACO Directory page 1 section header region

