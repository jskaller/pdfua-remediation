# dc_aco_ip_directory_11-9-2020.pdf

Status: VERAPDF_PASS_REVIEW_REQUIRED

## Validation
- veraPDF PDF/UA-1: PASS
- qpdf 12.3.2 --check: PASS

## Rework performed
- Rebuilt from source extraction using live/selectable text and controlled embedded fonts.
- Preserved source filled rectangles/rules and reverse-text section header bands, including page 1 headers such as Addiction Medicine and Addiction Psychiatry.
- No full-page rasterization.
- No OCR substitution.

## QA gates
- Page count preserved: 525 -> 525
- Text coverage: 261,036 words -> 261,036 words, ratio 1.0000
- Source drawing/header/rule objects preserved in output reconstruction: 1,227 -> 1,227
- File size: reduced from 2,797,909 bytes to 1,345,815 bytes
- Directory Section Header Preservation Gate: PASS on generated source/output page 1 crop and sampled pages
- Reverse Text / Filled Heading Gate: PASS for sampled page 1 and source-detected white-on-dark headings
- File-size gate: PASS

## Review-required reason
Although validation and QA gates pass, this remains review-required because the successful route is a native live-text rebuild from extraction rather than a direct source-object patch. The rebuilt directory should receive client-side visual spot-check review before being treated as final production copy.
