# Payment Rule Waivers-NG ACO Website 2017.pdf

Status: PRODUCTION_FINAL

## Validation
- veraPDF PDF/UA-1: PASS
- qpdf 12.3.2 --check: PASS

## Rework performed
- Rebuilt as live/selectable text with source-positioned text spans.
- Preserved the original one-row table visual treatment, including the blue header background, white table header text, table borders, and column alignment.
- No full-page rasterization.
- No OCR substitution.

## QA gates
- Page count preserved: 1 -> 1
- Text coverage: 49 words -> 49 words, ratio 1.0000
- Source drawing/table objects preserved in output reconstruction: 31 -> 31
- File size: reduced from 97,777 bytes to 44,117 bytes
- Table / Background Fill Preservation Gate: PASS
- Visual Style Preservation Gate: PASS
- File-size gate: PASS
